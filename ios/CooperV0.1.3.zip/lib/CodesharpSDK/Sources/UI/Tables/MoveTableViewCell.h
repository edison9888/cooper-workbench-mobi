//
//  MoveTableViewCell.h
//  CodesharpSDK
//
//  Created by sunleepy on 12-8-21.
//  Copyright (c) 2012年 codesharp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoveTableViewCell : UITableViewCell

- (void)prepareForMove;

@end
