//
//  MoveTableViewCell.m
//  CodesharpSDK
//
//  Created by sunleepy on 12-8-21.
//  Copyright (c) 2012年 codesharp. All rights reserved.
//

#import "MoveTableViewCell.h"

@implementation MoveTableViewCell

- (void)prepareForMove
{
    self.textLabel.text = @"";
	//[[self detailTextLabel] setText:@""];
	//[[self imageView] setImage:nil];
}

@end
